﻿using System;
using System.IO;

class Program
{
    static void Main()
    {
        string sourcePath = @"E:\CopyFrom\fileName.apk";
        string destinationPath = @"E:\PasteTo\fileName.apk";


        if (!File.Exists(sourcePath))
        {
            throw new FileNotFoundException("Source file not found.", sourcePath);
        }

        string destDirectory = Path.GetDirectoryName(destinationPath);
        if (!Directory.Exists(destDirectory))
        {
            Directory.CreateDirectory(destDirectory);
        }

        try
        {
            File.Copy(sourcePath, destinationPath, true);
            Console.WriteLine("File copied");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
            Console.ReadLine();
        }

    }

}
