--Simple Commands


INSERT INTO [HoverTestMultiple.Data].[dbo].[City] ([Name], [CountryId])
VALUES ('Mistaken City', 1);

UPDATE [HoverTestMultiple.Data].[dbo].[City]
SET CountryId = 2
where NAME = 'Mistaken City'

DELETE FROM [HoverTestMultiple.Data].[dbo].[City]
WHERE [Name] = 'Mistaken City';

--treat strink like number and check if is smaller than value
CAST(PickingNo AS INT) < 80000

--RESET ID TO 60
DBCC CHECKIDENT ('[HoverTestMultiple.Data].[dbo].[City]', RESEED, 60);
-- -2000000000


--Check for trimmed string
WHERE LTRIM(RTRIM(CustomerPoNo)) = 'ESAHS7601'

--Create a new view
CREATE VIEW dbo.V_ExistingOrdersCheck AS
SELECT
    HZPPN AS PartNumber,
    HZORNO AS OrderNo
FROM REPLICATION_MAP.S7835750.MMRFLLIB.IC010P

--remove username from element
alter schema dbo transfer [MMRMAKITA\a.pandele].Users

--duplicate table
SELECT * INTO new_table FROM existing_table

--Create a new table
  CREATE TABLE TestMap
(
	PickingNo varchar(20),
        SequenceNo int,
        ReceivingDate datetime
);

--Create copy of a table
SELECT *
INTO OperatorEvidencesTableCopy
FROM OperatorEvidencesTable;

--INSERT DATA INTO EXISTING TABLE
INSERT INTO CommandTypesPrefixTable
SELECT *
FROM CommandTypesPrefixTableCopy;

--Find duplicates
SELECT PickingNo, SequenceNo
FROM MapSequenceTable
GROUP BY PickingNo, SequenceNo
HAVING COUNT(*) > 1;


--create a new procedure
CREATE PROCEDURE MapDataSync

AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @RowCount INT;

    -- Count the rows with the specified @CountryCode
    SELECT *
    FROM v_pickingFileIC180P 

END;


--create table valued function
CREATE FUNCTION TestFunction
(
)
RETURNS TABLE
AS
RETURN
(
    SELECT *
    FROM v_pickingFileIC180P 
);

--small join 

SELECT          dbo.Users.Name,  dbo.OperatorEvidencesTable.PickerCount        
FROM            dbo.OperatorEvidencesTable INNER JOIN
                         dbo.Users ON dbo.OperatorEvidencesTable.EmployeeID = dbo.Users.EmployeeID
						 order by PickerCount desc


--find cascade constraints
select * from INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS 
where DELETE_RULE ='CASCADE'

--Join
SELECT        dbo.ActiveSequenceTable.PickingNo, dbo.ActiveSequenceTable.SequenceNo, dbo.ActiveSequenceTable.ReceivingOrdNo,
              dbo.BoxDetailsTable.BoxSerialStart
FROM            dbo.ActiveSequenceTable INNER JOIN
                   dbo.BoxDetailsTable ON dbo.ActiveSequenceTable.PickingNo = dbo.BoxDetailsTable.PickingNo AND dbo.ActiveSequenceTable.SequenceNo = dbo.BoxDetailsTable.SequenceNo
				   where dbo.ActiveSequenceTable.PickingNo > '75200'

--Temp Table Operations
CREATE TABLE #TempTable8312
(
    PickingNo nvarchar(50),
	SequenceNo int,
)

INSERT INTO #TempTable8312
SELECT dbo.BoxDetailsTable.PickingNo, dbo.BoxDetailsTable.SequenceNo
FROM [PS_PartCenter_Support_System].[dbo].[BoxDetailsTable]
where dbo.BoxDetailsTable.PickingNo > '75200'

SELECT *
FROM #TempTable8312

DROP TABLE #TempTable8312


--take list from one table and compare it with the other
SELECT DISTINCT A.*
FROM dbo.ActiveSequenceTable A
JOIN dbo.BoxDetailsTable B ON A.PickingNo = B.PickingNo AND A.SequenceNo = B.SequenceNo
WHERE NOT EXISTS (
    SELECT *
	FROM dbo.ActiveSequenceTable AS C
	WHERE C.PickingNo = A.PickingNo AND C.SequenceNo = A.SequenceNo
)

--for loop
DECLARE @Counter INT = 0;

WHILE @Counter < 1000
BEGIN
    INSERT INTO [ThirdStepRemake].[dbo].[AppUsers] 
        ([EmployeeID]
        ,[UserName]
        ,[FullName]
        ,[Email]
        ,[RoleId]
        ,[IsActive])
    VALUES ('1', '1', '1', '1', 1, 1);

    SET @Counter = @Counter + 1;
END