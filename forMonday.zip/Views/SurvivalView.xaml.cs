﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using NAudio.CoreAudioApi;
using NAudio.Gui;
using NAudio.Wave;
using OfficeOpenXml;
using SC3_pnach_editor.Codes;
using SC3_pnach_editor.Services;
using SC3_pnach_editor.ViewModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace SC3_pnach_editor.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class SurvivalView : UserControl
    {
        SurvivalViewModel viewModel;
        public SurvivalView()
        {

            InitializeComponent();

            viewModel = new();

            this.DataContext = viewModel;


            SettingsClass.LoadData();


            customSound.Source = new Uri(@"D:\Danger\Mods And Others\ps2\Soulcalibur 3\WPF Build\Extras\Char_Creation_Bgm.mp3");
            customSound.Volume = 0.1;


        }

        private void GoToMainPage_Click(object sender, RoutedEventArgs e)
        {
            viewModel.DisplayMainView();
        }

        private void TrainingArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            SurvivalModeCodes.GetSurvivalCode("TrainingArc");
        }

        private void AmateurArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            SurvivalModeCodes.GetSurvivalCode("AmateurArc");
        }

        private void IntermediateArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            SurvivalModeCodes.GetSurvivalCode("IntermediateArc");
        }

        private void AdvancedArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            SurvivalModeCodes.GetSurvivalCode("AdvancedArc");
        }

        private void ExpertArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            SurvivalModeCodes.GetSurvivalCode("ExpertArc");
        }

        private void MasterArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            SurvivalModeCodes.GetSurvivalCode("MasterArc");
        }

        private void AscendantArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            SurvivalModeCodes.GetSurvivalCode("AscendantArc");
        }

        private void JudgmentArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            SurvivalModeCodes.GetSurvivalCode("JudgmentArc");
        }

        private void GodArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            SurvivalModeCodes.GetSurvivalCode("GodArc");
        }

        private void SpecialArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            SurvivalModeCodes.GetSurvivalCode("SpecialArc");
        }

        private void TrainingArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Training Arc-----\n" +
                "\n" +
                "Welcome to the starting grounds.\n" +
                "Every enemy here is weakened and barely poses a threat,\n" +
                "with the simplest AI behavior imaginable.\n" +
                "It’s more target practice than combat,\n" +
                "the perfect place to learn the ropes\n" +
                "and sharpen your reflexes without fear.\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★\n";
        }
           
        private void AmateurArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Amateur Arc-----\n" +
                "\n" +
                "The first few waves use simple AI,\n" +
                "but the rest fight with improved tactics.\n" +
                "No nerfs this time,\n" +
                "just a gradually rising challenge.\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★★\n";
        }

        private void IntermediateArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Intermediate Arc-----\n" +
                "\n" +
                "Enemies now fight with slightly improved AI and begin using better weapons.\n" +
                "A good pick for a balanced challenge.\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★★★\n";
             
        }

        private void AdvancedArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Advanced Arc-----\n" +
                "\n" +
                "Enemies use tougher AI and slightly improved weapons.\n" +
                "Some are a bit faster, making things harder toward the end.\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★★★★\n";
        }

        private void ExpertArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Expert Arc-----\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★?\n";
        }

        private void MasterArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Master Arc-----\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★?\n";
        }

        private void AscendantArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Ascendant Arc-----\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★?\n";
        }

        private void JudgmentArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Judgment Arc-----\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★?\n";
        }

        private void GodArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----God Arc-----\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★?\n";
        }

        private void SpecialArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Special Arc-----\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★?\n";
        }

    }




}
