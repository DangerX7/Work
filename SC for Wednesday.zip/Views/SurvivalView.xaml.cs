﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using NAudio.CoreAudioApi;
using NAudio.Gui;
using NAudio.Wave;
using OfficeOpenXml;
using SC3_pnach_editor.Codes;
using SC3_pnach_editor.Services;
using SC3_pnach_editor.ViewModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace SC3_pnach_editor.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class SurvivalView : UserControl
    {
        SurvivalViewModel viewModel;
        public SurvivalView()
        {

            InitializeComponent();

            viewModel = new();

            this.DataContext = viewModel;


            SettingsClass.LoadData();


            customSound.Source = new Uri(@"D:\Danger\Mods And Others\ps2\Soulcalibur 3\WPF Build\Extras\Char_Creation_Bgm.mp3");
            customSound.Volume = 0.1;


        }

        private void GoToMainPage_Click(object sender, RoutedEventArgs e)
        {
            viewModel.DisplayMainView();
        }

        private void TrainingArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            string modeName = "Training Arc";
            GenerateCode(modeName);
        }

        private void AmateurArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            string modeName = "Amateur Arc";
            GenerateCode(modeName);
        }

        private void IntermediateArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            string modeName = "Intermediate Arc";
            GenerateCode(modeName);
        }

        private void AdvancedArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            string modeName = "Advanced Arc";
            GenerateCode(modeName);
        }

        private void ExpertArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            string modeName = "Expert Arc";
            GenerateCode(modeName);
        }

        private void MasterArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            string modeName = "Master Arc";
            GenerateCode(modeName);
        }

        private void ChampionArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            string modeName = "Champion Arc";
            GenerateCode(modeName);
        }

        private void LegendaryArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            string modeName = "Legendary Arc";
            GenerateCode(modeName);
        }

        private void GodArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            string modeName = "God Arc";
            GenerateCode(modeName);
        }

        private void SpecialArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            string modeName = "Special Arc";
            GenerateCode(modeName);
        }
        private void MysteriousArcSurvival_Click(object sender, RoutedEventArgs e)
        {
            string modeName = "Mysterious Arc";
            GenerateCode(modeName);
        }

        public void GenerateCode(string modeName)
        {
            SurvivalModeCodes.GetSurvivalCode(modeName, true);
            SettingsClass.SelectedSurvivalMode = modeName;
            SettingsClass.SaveData();
            viewModel.CodeInformation = "Mode " + modeName + " was activated succesfully";
        }

        private void TrainingArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Training Arc-----\n" +
                "\n" +
                "Welcome to the starting grounds.\n" +
                "Every enemy here is weakened and barely poses a threat,\n" +
                "with the simplest AI behavior imaginable.\n" +
                "It’s more target practice than combat,\n" +
                "the perfect place to learn the ropes\n" +
                "and sharpen your reflexes without fear.\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★\n";
        }
           
        private void AmateurArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Amateur Arc-----\n" +
                "\n" +
                "The first few waves use simple AI,\n" +
                "but the rest fight with improved tactics.\n" +
                "No nerfs this time,\n" +
                "just a gradually rising challenge.\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★★\n";
        }

        private void IntermediateArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Intermediate Arc-----\n" +
                "\n" +
                "Enemies now fight with slightly improved AI and begin using better weapons.\n" +
                "A good pick for a balanced challenge.\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★★★\n";
             
        }

        private void AdvancedArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Advanced Arc-----\n" +
                "\n" +
                "Enemies use tougher AI and slightly improved weapons.\n" +
                "Modifiers apear more often this time makin things harder.\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★★★★\n";
        }

        private void ExpertArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Expert Arc-----\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★★★★★\n";
        }

        private void MasterArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Master Arc-----\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★★★★★★\n";
        }

        private void ChampionArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Champion Arc-----\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★★★★★★★\n";
        }

        private void LegendaryArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Legendary Arc-----\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★★★★★★★★\n";
        }

        private void GodArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----God Arc-----\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★★★★★★★★★★\n";
        }

        private void SpecialArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Special Arc-----\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "Difficulty ★★★★★★★\n";
        }
        private void MysteriousArcSurvival_MouseEnter(object sender, MouseEventArgs e)
        {
            viewModel.ModeInformation = "-----Mysterious Arc-----\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "AI difficulty will be the one you selected in the main menu.\n" +
                "\n" +
                "\n" +
                "Difficulty ???\n";
        }

        private void Remove_Click(object sender, RoutedEventArgs e)
        {
            SettingsClass.SelectedSurvivalMode = "";
            SettingsClass.SaveData();
            viewModel.CodeInformation = "Code was set to empty";
        }


    }




}
