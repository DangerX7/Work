﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SC3_pnach_editor.Services;
using SC3_pnach_editor.ViewModelsClasses;
using System.IO;

namespace SC3_pnach_editor.Codes
{
    public class SurvivalModeCodes
    {
        public static string GetSurvivalCode(string survivalName, bool liteMode)
        {
            //Try to fix Cassandra yellow skin somehow

            //Danger test = ExpertArc
            SurvivalList survivalCode = new SurvivalList();
            List<string> survivalPnach = new List<string>();
            string stageCode = "";
            switch (survivalName)
            {
                #region Training Arc
                case "Training Arc":
                    survivalCode.stageLevel = "000D";
                    survivalCode.stageMusic = "0D";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "86";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "00"; //Gladiator 2 

                    survivalCode.aiLevel = "00"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = "04"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "8C";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "41";
                    survivalCode.weaponNumber = "00"; //Fu-ma Ninja 5

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = "04"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "97";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "47";
                    survivalCode.weaponNumber = "00"; //Sentry

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = "04"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "B3";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "4B";
                    survivalCode.weaponNumber = "00"; //Aika

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F40"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "AA";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "46";
                    survivalCode.weaponNumber = "00"; //Ignis

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F40"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0001";
                    survivalCode.stageMusic = "01";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "54";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "54";
                    survivalCode.weaponNumber = "00"; //Revenant

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets ; no means will trip
                    survivalCode.speed = "3F40"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "4A";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "4A";
                    survivalCode.weaponNumber = "00"; //Demuth

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = "Poison P2"; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets ; no means will trip
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "84";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "00"; //Samurai 3

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = "Poison P2"; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets ; no means will trip
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "A2";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "42";
                    survivalCode.weaponNumber = "00"; //Saizou

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = "Poison P2"; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets ; no means will trip
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "B8";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "4E";
                    survivalCode.weaponNumber = "00"; //Feofan

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = "Poison P2"; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets ; no means will trip
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0016";
                    survivalCode.stageMusic = "16";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "1E";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "0E";
                    survivalCode.weaponNumber = "06"; //Lizard Men

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "1A";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "1A";
                    survivalCode.weaponNumber = "06"; //Yun-Seong

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "0F";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "0F";
                    survivalCode.weaponNumber = "06"; //Yoshimitsu

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "08";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "08";
                    survivalCode.weaponNumber = "06"; //Rock

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "11";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "11";
                    survivalCode.weaponNumber = "06"; //Nightmare

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0010";
                    survivalCode.stageMusic = "10";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "16";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "16";
                    survivalCode.weaponNumber = "06"; //Talim

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "35";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "24";
                    survivalCode.weaponNumber = "06"; //Zasalamel

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "25";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "25";
                    survivalCode.weaponNumber = "06"; //Olcadan

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "07";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "07";
                    survivalCode.weaponNumber = "06"; //Siegfried

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "93";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "42";
                    survivalCode.weaponNumber = "03"; //Assassin

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    break;
                #endregion

                #region Amateur Arc
                case "Amateur Arc":
                    survivalCode.stageLevel = "0011";
                    survivalCode.stageMusic = "11";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "BF";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "54";
                    survivalCode.weaponNumber = "00"; //Riese

                    survivalCode.aiLevel = "00"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "C1";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "30";
                    survivalCode.weaponNumber = "00"; //Eris

                    survivalCode.aiLevel = "00"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "96";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "00"; //General

                    survivalCode.aiLevel = "00"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "90";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4C";
                    survivalCode.weaponNumber = "00"; //Thief 2

                    survivalCode.aiLevel = "00"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "AF";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "00"; //Brunhild

                    survivalCode.aiLevel = "00"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "000B";
                    survivalCode.stageMusic = "0B";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "ED";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4E";
                    survivalCode.weaponNumber = "00"; //Hyle

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "E4";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4C";
                    survivalCode.weaponNumber = "00"; //Chester

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "46";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "46";
                    survivalCode.weaponNumber = "00"; //Valeria

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "8A";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "42";
                    survivalCode.weaponNumber = "00"; //Fu-ma Ninja 1

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "A0";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "41";
                    survivalCode.weaponNumber = "00"; //Jinkai

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0018";
                    survivalCode.stageMusic = "18";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "22";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "22";
                    survivalCode.weaponNumber = "00"; //Setsuka

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "04";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "04";
                    survivalCode.weaponNumber = "00"; //Maxi

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "36";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "0E";
                    survivalCode.weaponNumber = "00"; //Lizardman

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "84";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "00"; //Samurai 1

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "B7";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "00"; //Eurydice

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "000A";
                    survivalCode.stageMusic = "0A";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "01";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "01";
                    survivalCode.weaponNumber = "00"; //Mitsurugi

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "06";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "06";
                    survivalCode.weaponNumber = "00"; //Sophitia

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "89";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "00"; //Unknown Soul

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "14";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "14";
                    survivalCode.weaponNumber = "00"; //Cervantes

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "99";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "44";
                    survivalCode.weaponNumber = "06"; //Dragon

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = "3FA00000"; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);

                    break;
                #endregion

                #region Intermediate Arc
                case "Intermediate Arc":
                    survivalCode.stageLevel = "0009";
                    survivalCode.stageMusic = "09";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "0B";
                    survivalCode.costume = "09";
                    survivalCode.fightingStyle = "0B";
                    survivalCode.weaponNumber = "02"; //Ivy

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "0D";
                    survivalCode.costume = "09";
                    survivalCode.fightingStyle = "0D";
                    survivalCode.weaponNumber = "02"; //Xianghua

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "12";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "12";
                    survivalCode.weaponNumber = "02"; //Astaroth

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "23";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "23";
                    survivalCode.weaponNumber = "02"; //Tira

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "25";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "25";
                    survivalCode.weaponNumber = "02"; //Olcadan

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0007";
                    survivalCode.stageMusic = "07";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "07";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "07";
                    survivalCode.weaponNumber = "02"; //Siegfried

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "15";
                    survivalCode.costume = "09";
                    survivalCode.fightingStyle = "15";
                    survivalCode.weaponNumber = "02"; //Raphael

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "17";
                    survivalCode.costume = "09";
                    survivalCode.fightingStyle = "17";
                    survivalCode.weaponNumber = "02"; //Cassandra

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "30";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "30";
                    survivalCode.weaponNumber = "01"; //Amy

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "2A";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "2A";
                    survivalCode.weaponNumber = "00"; //Charade

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = "05"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0013";
                    survivalCode.stageMusic = "13";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "88";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "1A";
                    survivalCode.weaponNumber = "00"; //Unknown Soul

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "2E";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "2E";
                    survivalCode.weaponNumber = "01"; //Shadow Master

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "91";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4C";
                    survivalCode.weaponNumber = "01"; //Pirate 1

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "B9";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4E";
                    survivalCode.weaponNumber = "02"; //Eunice

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "A1";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "41";
                    survivalCode.weaponNumber = "02"; //Chikage

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "000C";
                    survivalCode.stageMusic = "0C";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "BC";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "51";
                    survivalCode.weaponNumber = "00"; //Dufeng

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "94";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "45";
                    survivalCode.weaponNumber = "03"; //Swordsman 1

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "4B";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "4B";
                    survivalCode.weaponNumber = "00"; //Aurelia

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "8B";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4B";
                    survivalCode.weaponNumber = "01"; //Fu-ma Ninja 2

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "AE";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "07"; //Rudiger

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    break;
                #endregion

                #region Advanced Arc
                case "Advanced Arc":
                    survivalCode.stageLevel = "0002";
                    survivalCode.stageMusic = "02";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "14";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "14";
                    survivalCode.weaponNumber = "04"; //Cervantes

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "E7";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "03"; //Aege

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "B1";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "4A";
                    survivalCode.weaponNumber = "03"; //Azalea

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "42";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "42";
                    survivalCode.weaponNumber = "02"; //Greed

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "A4";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "01"; //Meiga

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0005";
                    survivalCode.stageMusic = "05";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "EE";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "45";
                    survivalCode.weaponNumber = "07"; //Mooncalf

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "B6";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "04"; //Balduin

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "29";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "29";
                    survivalCode.weaponNumber = "03"; //Charade

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = "00"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "41";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "41";
                    survivalCode.weaponNumber = "03"; //Miser

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "B0";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "4A";
                    survivalCode.weaponNumber = "04"; //Aeolos

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0004";
                    survivalCode.stageMusic = "04";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "92";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "44";
                    survivalCode.weaponNumber = "02"; //Pirate 6

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "0B";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "0B";
                    survivalCode.weaponNumber = "04"; //Ivy

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "44";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "44";
                    survivalCode.weaponNumber = "05"; //Hwang

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "12";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "12";
                    survivalCode.weaponNumber = "05"; //Astaroth

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F60"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "26";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "26";
                    survivalCode.weaponNumber = "01"; //Abyss

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0000";
                    survivalCode.stageMusic = "00";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "84";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "01"; //Samurai 1

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "02";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "02";
                    survivalCode.weaponNumber = "02"; //Seong Mi-na

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "98";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "00"; //Keres

                    survivalCode.aiLevel = "00"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "8A";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "42";
                    survivalCode.weaponNumber = "01"; //Fu-ma Ninja 1

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "B6";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "06"; //Areon

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    break;
                #endregion

                #region Expert Arc
                case "Expert Arc":
                    survivalCode.stageLevel = "0015";
                    survivalCode.stageMusic = "15";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "26";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "26";
                    survivalCode.weaponNumber = "00"; //Abyss

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "03";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "03";
                    survivalCode.weaponNumber = "02"; //Taki

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "1E";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "0E";
                    survivalCode.weaponNumber = "04"; //Lizard Men

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "43";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "03"; //Arthur

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "84";
                    survivalCode.costume = "03";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "02"; //Samurai 4

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "3FB00000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0006";
                    survivalCode.stageMusic = "06";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "B6";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "07"; //Aloces

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "E0";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "4E";
                    survivalCode.weaponNumber = "05"; //Abelia

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "2E";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "2E";
                    survivalCode.weaponNumber = "04"; //Shadow Master

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "48";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "04"; //Girardot

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "3FC00000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "28";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "28";
                    survivalCode.weaponNumber = "06"; //Charade

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = "Cure"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = "00"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "000E";
                    survivalCode.stageMusic = "0E";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "81";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "01"; //Berserker

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = "3F800000"; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "A6";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "44";
                    survivalCode.weaponNumber = "01"; //Xiaoxin

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "AC";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "47";
                    survivalCode.weaponNumber = "02"; //Xunyu

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F88"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = "3E800000"; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = "3EA00000"; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = "3F000000"; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "EA";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "02"; //Lupi

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = "00080000"; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = "3F400000"; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = "3F000000"; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "EF";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "01";
                    survivalCode.weaponNumber = "02"; //Yotory

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = "3E000000"; //Damage inflicted thru guard
                    survivalCode.weaponSize = "3FA00000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0017";
                    survivalCode.stageMusic = "17";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "EC";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "46";
                    survivalCode.weaponNumber = "06"; //Kierkess

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F88"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "E8";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "42";
                    survivalCode.weaponNumber = "02"; //Elua

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "BC";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "51";
                    survivalCode.weaponNumber = "03"; //Yakumo

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "11";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "11";
                    survivalCode.weaponNumber = "05"; //Nightmare

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F88"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = "40000000"; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "EF";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "06"; //Ende

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F88"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    break;
                #endregion

                #region Master Arc
                case "Master Arc":
                    survivalCode.stageLevel = "0210";
                    survivalCode.stageMusic = "10";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "EF";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "01";
                    survivalCode.weaponNumber = "05"; //Yotory

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = "3D000000"; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "B4";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "4C";
                    survivalCode.weaponNumber = "05"; //Celestis

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = "Cure"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F88"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "96";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "03"; //General

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = "05"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F40"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "2E";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "2E";
                    survivalCode.weaponNumber = "05"; //Shadow Master

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = "3C000000"; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "81";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "03"; //Berserker

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F40"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0014";
                    survivalCode.stageMusic = "16";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "AF";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "06"; //Annaretta

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "3FC00000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "A0";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "41";
                    survivalCode.weaponNumber = "04"; //Kagami

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "A4";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "06"; //Shizuma

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = "04"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FE0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "AA";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "46";
                    survivalCode.weaponNumber = "04"; //Notus

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = "3F000000"; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "31";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "31";
                    survivalCode.weaponNumber = "00"; //Colossus

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0005";
                    survivalCode.stageMusic = "05";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "8B";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "4B";
                    survivalCode.weaponNumber = "05"; //Fu-ma Ninja 3

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = "3F000000"; //Steal health from enemy
                    survivalCode.pierceDamage = "3E000000"; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "07";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "07";
                    survivalCode.weaponNumber = "05"; //Siegfried

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = "3EE00000"; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "24";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "24";
                    survivalCode.weaponNumber = "05"; //Zasalamel

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = "B2000000"; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "15";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "15";
                    survivalCode.weaponNumber = "05"; //Raphael

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "EB";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "06"; //Roin

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F98"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "40000000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0101";
                    survivalCode.stageMusic = "15";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "B8";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4E";
                    survivalCode.weaponNumber = "05"; //Rufus

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "8C";
                    survivalCode.costume = "03";
                    survivalCode.fightingStyle = "41";
                    survivalCode.weaponNumber = "04"; //Fu-ma Ninja 7

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "25";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "25";
                    survivalCode.weaponNumber = "05"; //Olcadan

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "03";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "03";
                    survivalCode.weaponNumber = "05"; //Taki

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "3FB000000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "26";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "26";
                    survivalCode.weaponNumber = "01"; //Abyss

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    break;
                #endregion

                #region Champion Arc
                case "Champion Arc":
                    survivalCode.stageLevel = "0008";
                    survivalCode.stageMusic = "08";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "15";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "15";
                    survivalCode.weaponNumber = "05"; //Raphael

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "0D";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "0D";
                    survivalCode.weaponNumber = "05"; //Xianghua

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "14";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "14";
                    survivalCode.weaponNumber = "05"; //Cervantes

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "01";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "01";
                    survivalCode.weaponNumber = "05"; //Mitsurugi

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "11";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "11";
                    survivalCode.weaponNumber = "05"; //Nightmare

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0003";
                    survivalCode.stageMusic = "03";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "51";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "51";
                    survivalCode.weaponNumber = "04"; //Li Long

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "81";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "00"; //Berserker

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FB0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "23";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "23";
                    survivalCode.weaponNumber = "05"; //Tira

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "02";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "02";
                    survivalCode.weaponNumber = "05"; //Seong Mi-na

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "28";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "26";
                    survivalCode.weaponNumber = ""; //Charade

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FB0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "000F";
                    survivalCode.stageMusic = "0F";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "47";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "47";
                    survivalCode.weaponNumber = "04"; //Hualin

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = "40000000"; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = "40000000"; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = "BF000000"; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "E1";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "45";
                    survivalCode.weaponNumber = "05"; //Luna

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = "3F200000"; //Damage inflicted thru guard
                    survivalCode.weaponSize = "40000000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "4F";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4F";
                    survivalCode.weaponNumber = "04"; //Lynette

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "E8";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "54";
                    survivalCode.weaponNumber = "04"; //HealDo

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = "3C800000"; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "54";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "54";
                    survivalCode.weaponNumber = "06"; //Strife

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = "3FD00000"; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0201";
                    survivalCode.stageMusic = "01";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "17";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "17";
                    survivalCode.weaponNumber = "05"; //Cassandra

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F98"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "0B";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "0B";
                    survivalCode.weaponNumber = "05"; //Ivy

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "3FD00000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "07";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "07";
                    survivalCode.weaponNumber = "05"; //Siegfried

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = "3F400000"; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = "3C400000"; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = "40000000"; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = "40000000"; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "11";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "11";
                    survivalCode.weaponNumber = "05"; //Nightmare

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F40"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "06";
                    survivalCode.costume = "09";
                    survivalCode.fightingStyle = "06";
                    survivalCode.weaponNumber = "05"; //Sophitia

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Cure"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = "3F200000"; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    break;
                #endregion

                #region Legendary Arc
                case "Legendary Arc":
                    survivalCode.stageLevel = "0109";
                    survivalCode.stageMusic = "09";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "0C";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "0C";
                    survivalCode.weaponNumber = "07"; //Kilik

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "05";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "05";
                    survivalCode.weaponNumber = "07"; //Voldo

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FB0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "0F";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "0F";
                    survivalCode.weaponNumber = "07"; //Yoshimitsu

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "24";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "24";
                    survivalCode.weaponNumber = "07"; //Zasalamel

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = "3FB80000"; //Decrease/Increase Attack
                    survivalCode.defense = "3F600000"; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "AE";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = "07"; //Aeneas

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F88"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "40000000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = "3D800000"; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = "C0000000"; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0210";
                    survivalCode.stageMusic = "10";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "03";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "03";
                    survivalCode.weaponNumber = "07"; //Taki

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA8"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "01";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "01";
                    survivalCode.weaponNumber = "07"; //Mitsurugi

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "23";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "23";
                    survivalCode.weaponNumber = "07"; //Tira

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F88"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "16";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "16";
                    survivalCode.weaponNumber = "07"; //Talim

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "11";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "11";
                    survivalCode.weaponNumber = "07"; //Nightmare

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "40000000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0012";
                    survivalCode.stageMusic = "12";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "05";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "05";
                    survivalCode.weaponNumber = "07"; //Voldo

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Cure"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "1A";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "1A";
                    survivalCode.weaponNumber = "07"; //Yun-Seong

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Poison"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FB0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "04";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "04";
                    survivalCode.weaponNumber = "07"; //Maxi

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "22";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "22";
                    survivalCode.weaponNumber = "07"; //Setsuka

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA8"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "3FB00000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "17";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "17";
                    survivalCode.weaponNumber = "07"; //Cassandra

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F98"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = "3FB00000"; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0019";
                    survivalCode.stageMusic = "19";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "08";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "08";
                    survivalCode.weaponNumber = "07"; //Rock

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F88"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "06";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "06";
                    survivalCode.weaponNumber = "07"; //Sophitia

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "0D";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "0D";
                    survivalCode.weaponNumber = "07"; //Xianghua

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "07";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "07";
                    survivalCode.weaponNumber = "07"; //Siegfried

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = "05"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F40"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "2B";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "14";
                    survivalCode.weaponNumber = "05"; //Inferno

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = "00"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = "40000000"; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = "00000000"; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    break;
                #endregion

                //1 Hell full of OP bosses
                #region God Arc
                case "God Arc":
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "98";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "02"; //Keres

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "3F900000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    break;
                #endregion

                //1 Special with my created characters
                #region Special Arc
                case "Special Arc":
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = ""; //

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += GetStageCode(survivalCode);
                    break;
                    #endregion

            }

            string timeCode = Environment.NewLine + "patch=1,EE,204ED89C,extended,000003E8 //Time Limit set to 1000 seconds" + Environment.NewLine;
            stageCode = timeCode + stageCode;

            string survivalCodeNotLite = stageCode;

            SettingsClass.LoadData();
            stageCode += Codes.NewWeapons.GetWeaponsCode(SettingsClass.UltimateWeapons, false, false);
            stageCode += Codes.CharacterSelect.GetCharacterPnachCode(true, true);

            File.WriteAllText(SettingsClass.codeFilePath, stageCode, Encoding.UTF8);

            if (liteMode == true)
            {
                return "ok";
            }
            else
            {
                return survivalCodeNotLite;
            }
        }

        public static string GetStageCode(SurvivalList survivalCode)
        {
            string stageNumberValue = "";
            switch (survivalCode.stageNumber)
            {
                case 1:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,00000000//If you kill 0 enemies (Set enemy 1)";
                    break;
                case 2:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,00000001//If you kill 1 enemies (Set enemy 2)";
                    break;
                case 3:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,00000002//If you kill 2 enemies (Set enemy 3)";
                    break;
                case 4:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,00000003//If you kill 3 enemies (Set enemy 4)";
                    break;
                case 5:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,00000004//If you kill 4 enemies (Set enemy 5)";
                    break;
                case 6:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,00000005//If you kill 5 enemies (Set enemy 6)";
                    break;
                case 7:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,00000006//If you kill 6 enemies (Set enemy 7)";
                    break;
                case 8:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,00000007//If you kill 7 enemies (Set enemy 8)";
                    break;
                case 9:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,00000008//If you kill 8 enemies (Set enemy 9)";
                    break;
                case 10:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,00000009//If you kill 9 enemies (Set enemy 10)";
                    break;
                case 11:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,0000000A//If you kill 10 enemies (Set enemy 11)";
                    break;
                case 12:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,0000000B//If you kill 11 enemies (Set enemy 12)";
                    break;
                case 13:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,0000000C//If you kill 12 enemies (Set enemy 13)";
                    break;
                case 14:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,0000000D//If you kill 13 enemies (Set enemy 14)";
                    break;
                case 15:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,0000000E//If you kill 14 enemies (Set enemy 15)";
                    break;
                case 16:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,0000000F//If you kill 15 enemies (Set enemy 16)";
                    break;
                case 17:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,00000010//If you kill 16 enemies (Set enemy 17)";
                    break;
                case 18:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,00000011//If you kill 17 enemies (Set enemy 18)";
                    break;
                case 19:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,00000012//If you kill 18 enemies (Set enemy 19)";
                    break;
                case 20:
                    stageNumberValue = "patch=1,EE,D04B6F5C,extended,00000013//If you kill 19 enemies (Set enemy 20)";
                    break;
            }

            string stageLevelValue = "";
            if (survivalCode.stageLevel != "")
            {
                string stageMusicPiece = "patch=1,EE,004ED648,extended,000000" + survivalCode.stageMusic + " //Music code";
                string stageLevelPiece = "patch=1,EE,004ED64C,extended,0000" + survivalCode.stageLevel + " //Level code";
                
                stageLevelValue = stageNumberValue + Environment.NewLine + stageMusicPiece + Environment.NewLine +
                                  stageNumberValue + Environment.NewLine + stageLevelPiece + Environment.NewLine;
            }

            if (survivalCode.fightingStyle == "25")//Olcadan
            {
                List<string> standardChars = new List<string> { "01", "02", "03", "04", "05", "06", "07", "08", "0B", "0C", "0D",
                "0E", "0F", "11", "12", "14", "15", "16", "17", "1A", "22", "23", "24" };

                Random rnd = new Random();
                survivalCode.fightingStyle = standardChars[rnd.Next(standardChars.Count)];
            }
            if (survivalCode.fightingStyle == "2E")//Shadow Master
            {
                List<string> bonusChars = new List<string> { "30", "41", "42","43", "44", "45", "46",
                "47", "48", "4A", "4B", "4C", "4D", "4E", "4F", "51", "54" };

                Random rnd = new Random();
                survivalCode.fightingStyle = bonusChars[rnd.Next(bonusChars.Count)];
            }
            if (survivalCode.fightingStyle == "FF")//Edge Master
            {
                List<string> allChars = new List<string> { "01", "02", "03", "04", "05", "06", "07", "08", "0B", "0C", "0D",
                "0E", "0F", "11", "12", "14", "15", "16", "17", "1A", "22", "23", "24", "26",
                    "30", "41", "42","43", "44", "45", "46",
                "47", "48", "4A", "4B", "4C", "4D", "4E", "4F", "51", "54" };

                Random rnd = new Random();
                survivalCode.fightingStyle = allChars[rnd.Next(allChars.Count)];
            }

            string charPiece1 = "patch=1,EE,204D1FE0,extended,00" + survivalCode.fightingStyle + "00" + survivalCode.model + " // fighting style + model";
            charPiece1 = stageNumberValue + Environment.NewLine + charPiece1 + Environment.NewLine;
            string charPiece2 = "";
            //Charade special conditions
            if (survivalCode.fightingStyle == "28")
            {
                charPiece2 = "patch=1,EE,204D1FE4,extended,00" + survivalCode.fightingStyle + "00" + "54" + " // weapon gfx mapping (use fighting style)";
            }
            else if (survivalCode.fightingStyle == "29")
            {
                charPiece2 = "patch=1,EE,204D1FE4,extended,00" + survivalCode.fightingStyle + "00" + "46" + " // weapon gfx mapping (use fighting style)";
            }
            else if (survivalCode.fightingStyle == "2A")
            {
                charPiece2 = "patch=1,EE,204D1FE4,extended,00" + survivalCode.fightingStyle + "00" + "17" + " // weapon gfx mapping (use fighting style)";
            }
            else
            {
                charPiece2 = "patch=1,EE,204D1FE4,extended,00" + survivalCode.fightingStyle + "00" + survivalCode.fightingStyle + " // weapon gfx mapping (use fighting style)";
            }
            charPiece2 = stageNumberValue + Environment.NewLine + charPiece2 + Environment.NewLine;
            string charPiece3 = "";
            if (survivalCode.fightingStyle == "2A")
            {
                charPiece3 = "patch=1,EE,204D1FE8,extended,000100" + survivalCode.fightingStyle + " // type + weapon gfx mapping (use fighting style)";
            }
            else
            {
                charPiece3 = "patch=1,EE,204D1FE8,extended,000100" + survivalCode.fightingStyle + " // type + weapon gfx mapping (use fighting style)";
            }
            charPiece3 = stageNumberValue + Environment.NewLine + charPiece3 + Environment.NewLine;
            string charPiece4 = "patch=1,EE,204D1FEC,extended,00" + survivalCode.costume + "00" + survivalCode.model + " // costume + model";
            charPiece4 = stageNumberValue + Environment.NewLine + charPiece4 + Environment.NewLine;
            string charPiece5 = "patch=1,EE,004D2016,extended," + survivalCode.weaponNumber + " //Selected Weapon";
            charPiece5 = stageNumberValue + Environment.NewLine + charPiece5 + Environment.NewLine;

            string specPiece1 = "";
            if (survivalCode.aiLevel != "")
            {
                specPiece1 = "patch=1,EE,10520D54,extended,00" + survivalCode.aiLevel + " //opponent AI";
                specPiece1 = stageNumberValue + Environment.NewLine + specPiece1 + Environment.NewLine;
            }

            string specPiece2 = "";
            string weaponSpecialPiece1 = "";
            string weaponSpecialPiece2 = "";
            string weaponSpecialPiece3 = "";
            string weaponSpecialPiece4 = "";
            switch (survivalCode.weaponSpecial)
            {
                case "Thunder":
                    weaponSpecialPiece1 = "patch=1,EE,104ED9CA,extended,0001 //Enable weapon effects [Shared]" + Environment.NewLine;
                    weaponSpecialPiece2 = "patch=1,EE,1053CE1C,extended,0002 //Thunder Effect P2" + Environment.NewLine;
                    weaponSpecialPiece3 = "patch=1,EE,1053CF20,extended,0001 //Thunder Gfx P2" + Environment.NewLine;
                    weaponSpecialPiece4 = "patch=1,EE,2053CD40,extended,00010002 //Thunder Effect + Gfx P2 [Shared]" + Environment.NewLine;
                    break;
                case "Fire":
                    weaponSpecialPiece1 = "patch=1,EE,104ED9CA,extended,0001 //Enable weapon effects [Shared]" + Environment.NewLine;
                    weaponSpecialPiece2 = "patch=1,EE,1053CE18,extended,0002 //Fire Effect P2" + Environment.NewLine;
                    weaponSpecialPiece3 = "patch=1,EE,1053CFB0,extended,0001 //Fire Gfx P2" + Environment.NewLine;
                    weaponSpecialPiece4 = "patch=1,EE,2053CD40,extended,00010002 //Fire Effect + Gfx P2 [Shared]" + Environment.NewLine;
                    break;
                case "Paralysis":
                    weaponSpecialPiece1 = "patch=1,EE,104ED9CA,extended,0001 //Enable weapon effects [Shared]" + Environment.NewLine;
                    weaponSpecialPiece2 = "patch=1,EE,1053CE14,extended,0001 //Paralysis Effect P2" + Environment.NewLine;
                    weaponSpecialPiece3 = "patch=1,EE,1053CFAC,extended,0002 //Paralysis Gfx P2" + Environment.NewLine;
                    weaponSpecialPiece4 = "patch=1,EE,2053CD40,extended,00020001 //Paralysis Effect + Gfx P2 [Shared]" + Environment.NewLine;
                    break;
                case "Down Lose":
                    weaponSpecialPiece1 = "patch=1,EE,104ED9CA,extended,0001 //Enable weapon effects [Shared]" + Environment.NewLine;
                    weaponSpecialPiece2 = "patch=1,EE,1053CF34,extended,0007 //Down Lose Effect P2" + Environment.NewLine;
                    weaponSpecialPiece3 = "patch=1,EE,2053CD40,extended,00010000 //Down Lose Effect P1 & P2 [Shared]" + Environment.NewLine;
                    weaponSpecialPiece4 = "//Chelt";
                    break;
                case "Cure":
                    weaponSpecialPiece1 = "patch=1,EE,104D23EE,extended,3D80 // Change Weapon Heal Stat" + Environment.NewLine;
                    weaponSpecialPiece2 = "patch=1,EE,104ED9CA,extended,0001 // Enable weapon effects [Shared]" + Environment.NewLine;
                    weaponSpecialPiece3 = "patch=1,EE,1053CF48,extended,0001 // Cure Gfx P2" + Environment.NewLine;
                    weaponSpecialPiece4 = "patch=1,EE,2053CD40,extended,00010000 // P2 Cure" + Environment.NewLine;
                    break;
                case "Poison P1":
                    weaponSpecialPiece1 = "patch=1,EE,104B4C6E,extended,BD80 // Change Weapon Damage Stat P1" + Environment.NewLine;
                    weaponSpecialPiece2 = "patch=1,EE,104ED9CA,extended,0001 // Enable weapon effects [Shared]" + Environment.NewLine;
                    weaponSpecialPiece3 = "patch=1,EE,1053CE40,extended,0001 // Poison Gfx P1" + Environment.NewLine;
                    weaponSpecialPiece4 = "patch=1,EE,2053CD40,extended,00000003 // P1 Poison" + Environment.NewLine;
                    break;
                case "Poison P2":
                    weaponSpecialPiece1 = "patch=1,EE,104D23EE,extended,BD80 // Change Weapon Damage Stat P2" + Environment.NewLine;
                    weaponSpecialPiece2 = "patch=1,EE,104ED9CA,extended,0001 // Enable weapon effects [Shared]" + Environment.NewLine;
                    weaponSpecialPiece3 = "patch=1,EE,1053CFCC,extended,0001 // Poison Gfx P2" + Environment.NewLine;
                    weaponSpecialPiece4 = "patch=1,EE,2053CD40,extended,00030000 // P2 Poison" + Environment.NewLine;
                    break;
            }
            if (survivalCode.weaponSpecial != "")
            {
                specPiece2 = stageNumberValue + Environment.NewLine + weaponSpecialPiece1 +
                             stageNumberValue + Environment.NewLine + weaponSpecialPiece2 +
                             stageNumberValue + Environment.NewLine + weaponSpecialPiece3 +
                             stageNumberValue + Environment.NewLine + weaponSpecialPiece4;
            }

            string specPiece3 = "";
            if (survivalCode.guardianForce != "")
            {
                if (survivalCode.guardianForce == "00")
                {
                    //fix for Charade and Inferno
                    specPiece3 = "patch=1,EE,204D2274,extended,00010000" + " //Guardian Force";
                }
                else
                {
                    specPiece3 = "patch=1,EE,204D2274,extended,000200" + survivalCode.guardianForce + " //Guardian Force";
                }
                specPiece3 = stageNumberValue + Environment.NewLine + specPiece3 + Environment.NewLine;
            }

            string specPiece4 = "";
            if (survivalCode.stickyFeet != "")
            {
                string stickyFeetPiece1 = "patch=1,EE,1053CD42,extended,0007 //Slippery Feets Player 2";
                string stickyFeetPiece2 = "patch=1,EE,1053CED8,extended,0001 //Can Fall Of The Ring Player 2";
                string stickyFeetPiece3 = "patch=1,EE,1053CEE4,extended,0001 //Slippery Feets Player 2";

                specPiece4 =  stageNumberValue + Environment.NewLine + stickyFeetPiece1 + Environment.NewLine +
                              stageNumberValue + Environment.NewLine + stickyFeetPiece2 + Environment.NewLine +
                              stageNumberValue + Environment.NewLine + stickyFeetPiece3 + Environment.NewLine;
            }

            string specPiece5 = "";
            if (survivalCode.speed != "")
            {
                string speedCodePiece1 = "patch=1,EE,200FFD0C,extended,3C01" + survivalCode.speed + "//P2";
                string speedCodePiece2 = "patch=1,EE,200FFD10,extended,3C04004D//P2";
                string speedCodePiece3 = "patch=1,EE,200FFD14,extended,AC8136D0//P2";
                string speedCodePiece4 = "patch=1,EE,200FFD18,extended,0260202D//BOTH";
                string speedCodePiece5 = "patch=1,EE,200FFD1C,extended,0806CDD1//BOTH";
                string speedCodePiece6 = "patch=1,EE,201B3740,extended,0803FF40//BOTH";

                specPiece5 = stageNumberValue + Environment.NewLine + speedCodePiece1 + Environment.NewLine +
                             stageNumberValue + Environment.NewLine + speedCodePiece2 + Environment.NewLine +
                             stageNumberValue + Environment.NewLine + speedCodePiece3 + Environment.NewLine +
                             stageNumberValue + Environment.NewLine + speedCodePiece4 + Environment.NewLine +
                             stageNumberValue + Environment.NewLine + speedCodePiece5 + Environment.NewLine +
                             stageNumberValue + Environment.NewLine + speedCodePiece6 + Environment.NewLine;
            }

            string wpnPiece1 = "";
            if (survivalCode.weaponEffect != "")
            {
                wpnPiece1 = "patch=1,EE,204D23AC,extended," + survivalCode.weaponEffect +
                    " //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform";
                wpnPiece1 = stageNumberValue + Environment.NewLine + wpnPiece1 + Environment.NewLine;
            }
            string wpnPiece2 = "";
            if (survivalCode.attack != "")
            {
                wpnPiece2 = "patch=1,EE,204D23B0,extended," + survivalCode.attack + " //Decrease/Increase Attack";
                wpnPiece2 = stageNumberValue + Environment.NewLine + wpnPiece2 + Environment.NewLine;
            }
            string wpnPiece3 = "";
            if (survivalCode.defense != "")
            {
                wpnPiece3 = "patch=1,EE,204D23B4,extended," + survivalCode.defense + " //Decrease/Increase Defense";
                wpnPiece3 = stageNumberValue + Environment.NewLine + wpnPiece3 + Environment.NewLine;
            }
            string wpnPiece4 = "";
            if (survivalCode.stealHp != "")
            {
                wpnPiece4 = "patch=1,EE,204D23B8,extended," + survivalCode.stealHp + " //Steal health from enemy";
                wpnPiece4 = stageNumberValue + Environment.NewLine + wpnPiece4 + Environment.NewLine;
            }
            string wpnPiece5 = "";
            if (survivalCode.pierceDamage != "")
            {
                wpnPiece5 = "patch=1,EE,204D23BC,extended," + survivalCode.pierceDamage + " //Damage inflicted thru guard";
                wpnPiece5 = stageNumberValue + Environment.NewLine + wpnPiece5 + Environment.NewLine;
            }
            string wpnPiece6 = "";
            if (survivalCode.weaponSize != "")
            {
                wpnPiece6 = "patch=1,EE,204D23C0,extended," + survivalCode.weaponSize + " //Steal health from enemy";
                wpnPiece6 = stageNumberValue + Environment.NewLine + wpnPiece6 + Environment.NewLine;
            }
            string wpnPiece7 = "";
            if (survivalCode.atkPushForce != "")
            {
                wpnPiece7 = "patch=1,EE,204D23C4,extended," + survivalCode.atkPushForce + " //Decrease/Increase Attack Pushback Force";
                wpnPiece7 = stageNumberValue + Environment.NewLine + wpnPiece7 + Environment.NewLine;
            }
            string wpnPiece8 = "";
            if (survivalCode.counterRate != "")
            {
                wpnPiece8 = "patch=1,EE,204D23C8,extended," + survivalCode.counterRate + " //Increase Counter Chance";
                wpnPiece8 = stageNumberValue + Environment.NewLine + wpnPiece8 + Environment.NewLine;
            }
            string wpnPiece9 = "";
            if (survivalCode.nullCounter != "")
            {
                wpnPiece9 = "patch=1,EE,204D23CC,extended," + survivalCode.nullCounter + " //Nullify Enemies Counters chance";
                wpnPiece9 = stageNumberValue + Environment.NewLine + wpnPiece9 + Environment.NewLine;
            }
            string wpnPiece10 = "";
            if (survivalCode.guardHpModify != "")
            {
                wpnPiece10 = "patch=1,EE,204D23D0,extended," + survivalCode.guardHpModify + " //Decrease/Increase Health while guarding enemies attacks";
                wpnPiece10 = stageNumberValue + Environment.NewLine + wpnPiece10 + Environment.NewLine;
            }
            string wpnPiece11 = "";
            if (survivalCode.autoGuardImpact != "")
            {
                wpnPiece11 = "patch=1,EE,204D23D4,extended," + survivalCode.autoGuardImpact + " //Automatically Guard Impact some attacks";
                wpnPiece11 = stageNumberValue + Environment.NewLine + wpnPiece11 + Environment.NewLine;
            }
            string wpnPiece12 = "";
            if (survivalCode.parryDamage != "")
            {
                wpnPiece12 = "patch=1,EE,204D23D8,extended," + survivalCode.parryDamage + " //Increase Damage Received by Opponent when successfully Guard Impact";
                wpnPiece12 = stageNumberValue + Environment.NewLine + wpnPiece12 + Environment.NewLine;
            }
            string wpnPiece13 = "";
            if (survivalCode.parryRegen != "")
            {
                wpnPiece13 = "patch=1,EE,204D23DC,extended," + survivalCode.parryRegen + " //Recover Health when successfully Guard Impact";
                wpnPiece13 = stageNumberValue + Environment.NewLine + wpnPiece13 + Environment.NewLine;
            }
            string wpnPiece14 = "";
            if (survivalCode.guardBreakRate != "")
            {
                wpnPiece14 = "patch=1,EE,204D23E0,extended," + survivalCode.guardBreakRate + " //Increase Guard Break Chance";
                wpnPiece14 = stageNumberValue + Environment.NewLine + wpnPiece14 + Environment.NewLine;
            }
            string wpnPiece15 = "";
            if (survivalCode.throwEscapeChance != "")
            {
                wpnPiece15 = "patch=1,EE,204D23E4,extended," + survivalCode.throwEscapeChance + " //Increase Throw Escape Rate";
                wpnPiece15 = stageNumberValue + Environment.NewLine + wpnPiece15 + Environment.NewLine;
            }
            string wpnPiece16 = "";
            if (survivalCode.ringOutEscapeChance != "")
            {
                wpnPiece16 = "patch=1,EE,204D23E8,extended," + survivalCode.ringOutEscapeChance + " //Increase Ring-Out Escape Rate";
                wpnPiece16 = stageNumberValue + Environment.NewLine + wpnPiece16 + Environment.NewLine;
            }
            string wpnPiece17 = "";
            if (survivalCode.hpRegenOrDrain != "")
            {
                wpnPiece17 = "patch=1,EE,204D23EC,extended," + survivalCode.hpRegenOrDrain + " //Drain/Recover Health over Time";
                wpnPiece17 = stageNumberValue + Environment.NewLine + wpnPiece17 + Environment.NewLine;
            }
            string wpnPiece18 = "";
            if (survivalCode.hpRegenOrDrainOnAtk != "")
            {
                wpnPiece18 = "patch=1,EE,204D23F0,extended," + survivalCode.hpRegenOrDrainOnAtk + " //Drain/Recover Health when Attacking";
                wpnPiece18 = stageNumberValue + Environment.NewLine + wpnPiece18 + Environment.NewLine;
            }

            string finalCode = Environment.NewLine +
                               stageLevelValue + 
                               charPiece1 + 
                               charPiece2 + 
                               charPiece3 + 
                               charPiece4 + 
                               charPiece5 + 
                               specPiece1 + 
                               specPiece2 + 
                               specPiece3 + 
                               specPiece4 + 
                               specPiece5 + 
                               wpnPiece1 + 
                               wpnPiece2 + 
                               wpnPiece3 + 
                               wpnPiece4 + 
                               wpnPiece5 + 
                               wpnPiece6 + 
                               wpnPiece7 + 
                               wpnPiece8 + 
                               wpnPiece9 + 
                               wpnPiece10 + 
                               wpnPiece11 + 
                               wpnPiece12 + 
                               wpnPiece13 + 
                               wpnPiece14 + 
                               wpnPiece15 + 
                               wpnPiece16 + 
                               wpnPiece17 + 
                               wpnPiece18 + Environment.NewLine; //etc add all

            return finalCode;
        }

    }
}
