﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SC3_pnach_editor.Services;
using SC3_pnach_editor.ViewModelsClasses;
using System.IO;

namespace SC3_pnach_editor.Codes
{
    public class SurvivalModeCodes
    {
        public static string GetSurvivalCode(string survivalName, bool liteMode)
        {
            //Try to fix Cassandra yellow skin somehow and Siegfried

            //Danger test = ExpertArc
            SurvivalList survivalCode = new SurvivalList();
            List<string> survivalPnach = new List<string>();
            string stageCode = "";
            switch (survivalName)
            {
                #region Training Arc
                case "Training Arc":
                    survivalCode.stageLevel = "000D";
                    survivalCode.stageMusic = "0D";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "86";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "00"; //Gladiator 2 

                    survivalCode.aiLevel = "00"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = "04"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "8C";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "41";
                    survivalCode.weaponNumber = "00"; //Fu-ma Ninja 5

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = "04"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "97";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "47";
                    survivalCode.weaponNumber = "00"; //Sentry

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = "04"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "B3";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "4B";
                    survivalCode.weaponNumber = "00"; //Aika

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F40"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "AA";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "46";
                    survivalCode.weaponNumber = "00"; //Ignis

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F40"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0001";
                    survivalCode.stageMusic = "01";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "54";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "54";
                    survivalCode.weaponNumber = "00"; //Revenant

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets ; no means will trip
                    survivalCode.speed = "3F40"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "4A";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "4A";
                    survivalCode.weaponNumber = "00"; //Demuth

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = "Poison P2"; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets ; no means will trip
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "84";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "00"; //Samurai 3

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = "Poison P2"; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets ; no means will trip
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "A2";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "42";
                    survivalCode.weaponNumber = "00"; //Cassius

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = "Poison P2"; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets ; no means will trip
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "B8";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "4E";
                    survivalCode.weaponNumber = "00"; //Feofan

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = "Poison P2"; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets ; no means will trip
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0016";
                    survivalCode.stageMusic = "16";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "1E";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "0E";
                    survivalCode.weaponNumber = "06"; //Lizard Men

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "1A";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "1A";
                    survivalCode.weaponNumber = "06"; //Yun-Seong

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "0F";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "0F";
                    survivalCode.weaponNumber = "06"; //Yoshimitsu

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "08";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "08";
                    survivalCode.weaponNumber = "06"; //Rock

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "11";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "11";
                    survivalCode.weaponNumber = "06"; //Nightmare

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0010";
                    survivalCode.stageMusic = "10";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "16";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "16";
                    survivalCode.weaponNumber = "06"; //Talim

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "35";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "24";
                    survivalCode.weaponNumber = "06"; //Zasalamel

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "25";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "25";
                    survivalCode.weaponNumber = "06"; //Olcadan

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "07";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "07";
                    survivalCode.weaponNumber = "06"; //Siegfried

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "93";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "42";
                    survivalCode.weaponNumber = "03"; //Assassin

                    survivalCode.aiLevel = "00"; // 0-5
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    break;
                #endregion

                #region Amateur Arc
                case "Amateur Arc":
                    survivalCode.stageLevel = "0011";
                    survivalCode.stageMusic = "11";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "BF";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "54";
                    survivalCode.weaponNumber = "00"; //Riese

                    survivalCode.aiLevel = "00"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "C1";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "30";
                    survivalCode.weaponNumber = "00"; //Eris

                    survivalCode.aiLevel = "00"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "95";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4E";
                    survivalCode.weaponNumber = "00"; //FootSoldier

                    survivalCode.aiLevel = "00"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "90";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4C";
                    survivalCode.weaponNumber = "00"; //Thief 2

                    survivalCode.aiLevel = "00"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "AF";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "00"; //Brunhild

                    survivalCode.aiLevel = "00"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "000B";
                    survivalCode.stageMusic = "0B";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "ED";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4E";
                    survivalCode.weaponNumber = "00"; //Hyle

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "E4";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4C";
                    survivalCode.weaponNumber = "00"; //Chester

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "46";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "46";
                    survivalCode.weaponNumber = "00"; //Valeria

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "8A";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "42";
                    survivalCode.weaponNumber = "00"; //Fu-ma Ninja 1

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "A0";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "41";
                    survivalCode.weaponNumber = "00"; //Jinkai

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0018";
                    survivalCode.stageMusic = "18";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "22";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "22";
                    survivalCode.weaponNumber = "00"; //Setsuka

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "04";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "04";
                    survivalCode.weaponNumber = "00"; //Maxi

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "36";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "0E";
                    survivalCode.weaponNumber = "00"; //Lizardman

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "84";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "00"; //Samurai 1

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "B7";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "00"; //Eurydice

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "000A";
                    survivalCode.stageMusic = "0A";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "01";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "01";
                    survivalCode.weaponNumber = "00"; //Mitsurugi

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "06";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "06";
                    survivalCode.weaponNumber = "00"; //Sophitia

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "89";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "00"; //Unknown Soul

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "14";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "14";
                    survivalCode.weaponNumber = "00"; //Cervantes

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "99";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "44";
                    survivalCode.weaponNumber = "06"; //Dragon

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F80"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = "3FA00000"; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    break;
                #endregion

                #region Intermediate Arc
                case "Intermediate Arc":
                    survivalCode.stageLevel = "0009";
                    survivalCode.stageMusic = "09";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "0B";
                    survivalCode.costume = "09";
                    survivalCode.fightingStyle = "0B";
                    survivalCode.weaponNumber = "02"; //Ivy

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "0D";
                    survivalCode.costume = "09";
                    survivalCode.fightingStyle = "0D";
                    survivalCode.weaponNumber = "02"; //Xianghua

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "12";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "12";
                    survivalCode.weaponNumber = "02"; //Astaroth

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "23";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "23";
                    survivalCode.weaponNumber = "02"; //Tira

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "25";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "25";
                    survivalCode.weaponNumber = "02"; //Olcadan

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0007";
                    survivalCode.stageMusic = "07";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "07";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "07";
                    survivalCode.weaponNumber = "02"; //Siegfried

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "15";
                    survivalCode.costume = "09";
                    survivalCode.fightingStyle = "15";
                    survivalCode.weaponNumber = "02"; //Raphael

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "17";
                    survivalCode.costume = "09";
                    survivalCode.fightingStyle = "17";
                    survivalCode.weaponNumber = "02"; //Cassandra

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "30";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "30";
                    survivalCode.weaponNumber = "01"; //Amy

                    survivalCode.aiLevel = "01"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "2A";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "2A";
                    survivalCode.weaponNumber = "00"; //Charade

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = "05"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0013";
                    survivalCode.stageMusic = "13";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "88";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "1A";
                    survivalCode.weaponNumber = "00"; //Unknown Soul

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "2E";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "2E";
                    survivalCode.weaponNumber = "01"; //Shadow Master

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "91";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4C";
                    survivalCode.weaponNumber = "01"; //Pirate 1

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "B9";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4E";
                    survivalCode.weaponNumber = "02"; //Eunice

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "A1";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "41";
                    survivalCode.weaponNumber = "02"; //Chikage

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "000C";
                    survivalCode.stageMusic = "0C";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "BC";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "51";
                    survivalCode.weaponNumber = "00"; //Dufeng

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "94";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "45";
                    survivalCode.weaponNumber = "03"; //Swordsman 1

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "4B";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "4B";
                    survivalCode.weaponNumber = "00"; //Aurelia

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "8B";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4B";
                    survivalCode.weaponNumber = "01"; //Fu-ma Ninja 2

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "AE";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "07"; //Rudiger

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    break;
                #endregion

                #region Advanced Arc
                case "Advanced Arc":
                    survivalCode.stageLevel = "0002";
                    survivalCode.stageMusic = "02";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "14";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "14";
                    survivalCode.weaponNumber = "04"; //Cervantes

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "E7";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "03"; //Aege

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "B1";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "4A";
                    survivalCode.weaponNumber = "03"; //Azalea

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "42";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "42";
                    survivalCode.weaponNumber = "02"; //Greed

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "A4";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "01"; //Meiga

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0005";
                    survivalCode.stageMusic = "05";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "EE";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "45";
                    survivalCode.weaponNumber = "07"; //Mooncalf

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "B6";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "04"; //Balduin

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "29";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "29";
                    survivalCode.weaponNumber = "03"; //Charade

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = "00"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "41";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "41";
                    survivalCode.weaponNumber = "03"; //Miser

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "B0";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "4A";
                    survivalCode.weaponNumber = "04"; //Aeolos

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0004";
                    survivalCode.stageMusic = "04";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "92";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "44";
                    survivalCode.weaponNumber = "02"; //Pirate 4

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "0B";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "0B";
                    survivalCode.weaponNumber = "04"; //Ivy

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "44";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "44";
                    survivalCode.weaponNumber = "05"; //Hwang

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "12";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "12";
                    survivalCode.weaponNumber = "05"; //Astaroth

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F60"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "26";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "26";
                    survivalCode.weaponNumber = "01"; //Abyss

                    survivalCode.aiLevel = "02"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0000";
                    survivalCode.stageMusic = "00";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "84";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "01"; //Samurai 2

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "02";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "02";
                    survivalCode.weaponNumber = "02"; //Seong Mi-na

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "98";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "00"; //Keres

                    survivalCode.aiLevel = "00"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "A2";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "42";
                    survivalCode.weaponNumber = "01"; //Saizou

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "B6";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "06"; //Areon

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    break;
                #endregion

                #region Expert Arc
                case "Expert Arc":
                    survivalCode.stageLevel = "0015";
                    survivalCode.stageMusic = "15";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "26";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "26";
                    survivalCode.weaponNumber = "00"; //Abyss

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "03";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "03";
                    survivalCode.weaponNumber = "02"; //Taki

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "1E";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "0E";
                    survivalCode.weaponNumber = "04"; //Lizard Men

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "43";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "03"; //Arthur

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "84";
                    survivalCode.costume = "03";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "02"; //Samurai 4

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "3FB00000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0006";
                    survivalCode.stageMusic = "06";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "B6";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "07"; //Aloces

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "E0";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "4E";
                    survivalCode.weaponNumber = "05"; //Abelia

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "2E";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "2E";
                    survivalCode.weaponNumber = "04"; //Shadow Master

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "48";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "04"; //Girardot

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "3FC00000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "28";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "28";
                    survivalCode.weaponNumber = "06"; //Charade

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = "Cure"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = "00"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "000E";
                    survivalCode.stageMusic = "0E";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "81";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "01"; //Berserker

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = "3F800000"; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "A6";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "44";
                    survivalCode.weaponNumber = "01"; //Xiaoxin

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "AC";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "47";
                    survivalCode.weaponNumber = "02"; //Xunyu

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F88"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = "3E800000"; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = "3EA00000"; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = "3F000000"; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "EA";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "02"; //Lupi

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = "00080000"; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = "3F400000"; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = "3F000000"; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "EF";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "01";
                    survivalCode.weaponNumber = "02"; //Yotory

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = "3E000000"; //Damage inflicted thru guard
                    survivalCode.weaponSize = "3FA00000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0017";
                    survivalCode.stageMusic = "17";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "EC";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "46";
                    survivalCode.weaponNumber = "06"; //Kierkess

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F88"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "E9";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "42";
                    survivalCode.weaponNumber = "02"; //Elua

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "BC";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "51";
                    survivalCode.weaponNumber = "03"; //Yakumo

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "11";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "11";
                    survivalCode.weaponNumber = "05"; //Nightmare

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F88"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = "40000000"; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "EF";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "06"; //Ende

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F88"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    break;
                #endregion

                #region Master Arc
                case "Master Arc":
                    survivalCode.stageLevel = "0210";
                    survivalCode.stageMusic = "10";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "EF";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "01";
                    survivalCode.weaponNumber = "05"; //Yotory

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = "3D000000"; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "B4";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "4C";
                    survivalCode.weaponNumber = "05"; //Celestis

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = "Cure"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F88"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "96";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "03"; //General

                    survivalCode.aiLevel = "03"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = "05"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F40"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "2E";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "2E";
                    survivalCode.weaponNumber = "05"; //Shadow Master

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = "3C000000"; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "81";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "03"; //Berserker

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F40"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0014";
                    survivalCode.stageMusic = "16";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "AF";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "06"; //Annaretta

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "3FC00000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "A0";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "41";
                    survivalCode.weaponNumber = "04"; //Kagami

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "A4";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "06"; //Shizuma

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = "04"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FE0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "AA";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "46";
                    survivalCode.weaponNumber = "04"; //Notus

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = "3F000000"; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "31";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "31";
                    survivalCode.weaponNumber = "00"; //Colossus

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0005";
                    survivalCode.stageMusic = "05";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "8E";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4B";
                    survivalCode.weaponNumber = "05"; //Bandit 2

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = "3F000000"; //Steal health from enemy
                    survivalCode.pierceDamage = "3E000000"; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "07";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "07";
                    survivalCode.weaponNumber = "05"; //Siegfried

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = "3EE00000"; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "24";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "24";
                    survivalCode.weaponNumber = "05"; //Zasalamel

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = "B2000000"; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "15";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "15";
                    survivalCode.weaponNumber = "05"; //Raphael

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "EB";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "06"; //Roin

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F98"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "40000000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0101";
                    survivalCode.stageMusic = "15";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "B8";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4E";
                    survivalCode.weaponNumber = "05"; //Rufus

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "8C";
                    survivalCode.costume = "03";
                    survivalCode.fightingStyle = "41";
                    survivalCode.weaponNumber = "04"; //Fu-ma Ninja 7

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "25";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "25";
                    survivalCode.weaponNumber = "05"; //Olcadan

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "03";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "03";
                    survivalCode.weaponNumber = "05"; //Taki

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "3FB000000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "26";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "26";
                    survivalCode.weaponNumber = "01"; //Abyss

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    break;
                #endregion

                #region Champion Arc
                case "Champion Arc":
                    survivalCode.stageLevel = "0008";
                    survivalCode.stageMusic = "08";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "15";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "15";
                    survivalCode.weaponNumber = "05"; //Raphael

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "0D";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "0D";
                    survivalCode.weaponNumber = "05"; //Xianghua

                    survivalCode.aiLevel = "04"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "14";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "14";
                    survivalCode.weaponNumber = "05"; //Cervantes

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "01";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "01";
                    survivalCode.weaponNumber = "05"; //Mitsurugi

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "11";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "11";
                    survivalCode.weaponNumber = "05"; //Nightmare

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0003";
                    survivalCode.stageMusic = "03";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "51";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "51";
                    survivalCode.weaponNumber = "04"; //Li Long

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "81";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "00"; //Berserker

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "23";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "23";
                    survivalCode.weaponNumber = "05"; //Tira

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "02";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "02";
                    survivalCode.weaponNumber = "05"; //Seong Mi-na

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "28";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "26";
                    survivalCode.weaponNumber = ""; //Charade

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "000F";
                    survivalCode.stageMusic = "0F";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "47";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "47";
                    survivalCode.weaponNumber = "04"; //Hualin

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = "40000000"; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = "40000000"; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = "BF000000"; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "E1";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "45";
                    survivalCode.weaponNumber = "05"; //Luna

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = "3F200000"; //Damage inflicted thru guard
                    survivalCode.weaponSize = "40000000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "4F";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4F";
                    survivalCode.weaponNumber = "04"; //Lynette

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "E8";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "54";
                    survivalCode.weaponNumber = "04"; //HealDo

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = "3C800000"; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "54";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "54";
                    survivalCode.weaponNumber = "06"; //Strife

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = "3FD00000"; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0201";
                    survivalCode.stageMusic = "01";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "17";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "17";
                    survivalCode.weaponNumber = "05"; //Cassandra

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F88"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "0B";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "0B";
                    survivalCode.weaponNumber = "05"; //Ivy

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "3FD00000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "07";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "07";
                    survivalCode.weaponNumber = "05"; //Siegfried

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = "3F400000"; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = "3C400000"; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = "40000000"; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = "40000000"; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "11";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "11";
                    survivalCode.weaponNumber = "05"; //Nightmare

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F40"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "06";
                    survivalCode.costume = "09";
                    survivalCode.fightingStyle = "06";
                    survivalCode.weaponNumber = "05"; //Sophitia

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Cure"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = "3F200000"; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    break;
                #endregion

                #region Legendary Arc
                case "Legendary Arc":
                    survivalCode.stageLevel = "0109";
                    survivalCode.stageMusic = "09";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "0C";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "0C";
                    survivalCode.weaponNumber = "07"; //Kilik

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F98"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "05";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "05";
                    survivalCode.weaponNumber = "07"; //Voldo

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FC0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "0F";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "0F";
                    survivalCode.weaponNumber = "07"; //Yoshimitsu

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "24";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "24";
                    survivalCode.weaponNumber = "07"; //Zasalamel

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = "3FB80000"; //Decrease/Increase Attack
                    survivalCode.defense = "3F600000"; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "AE";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = "07"; //Aeneas

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F88"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "40000000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = "3D800000"; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = "C0000000"; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0210";
                    survivalCode.stageMusic = "10";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "03";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "03";
                    survivalCode.weaponNumber = "07"; //Taki

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FB0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "01";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "01";
                    survivalCode.weaponNumber = "07"; //Mitsurugi

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "23";
                    survivalCode.costume = "08";
                    survivalCode.fightingStyle = "23";
                    survivalCode.weaponNumber = "07"; //Tira

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F88"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "16";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "16";
                    survivalCode.weaponNumber = "07"; //Talim

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F98"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "11";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "11";
                    survivalCode.weaponNumber = "07"; //Nightmare

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "40000000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0012";
                    survivalCode.stageMusic = "12";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "12";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "12";
                    survivalCode.weaponNumber = "07"; //Astaroth

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Poison P2"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = "05"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F58"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "1A";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "1A";
                    survivalCode.weaponNumber = "07"; //Yun-Seong

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Poison"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FB0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "04";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "04";
                    survivalCode.weaponNumber = "07"; //Maxi

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA8"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "22";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "22";
                    survivalCode.weaponNumber = "07"; //Setsuka

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA8"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "3FB00000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "17";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "17";
                    survivalCode.weaponNumber = "07"; //Cassandra

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F98"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = "3FB00000"; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0019";
                    survivalCode.stageMusic = "19";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "08";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "08";
                    survivalCode.weaponNumber = "07"; //Rock

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F60"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "06";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "06";
                    survivalCode.weaponNumber = "07"; //Sophitia

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA4"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "0D";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "0D";
                    survivalCode.weaponNumber = "07"; //Xianghua

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F94"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "07";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "07";
                    survivalCode.weaponNumber = "07"; //Siegfried

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F88"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "2B";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "14";
                    survivalCode.weaponNumber = "05"; //Inferno

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = "00"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FC0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = "40000000"; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = "00000000"; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    break;
                #endregion

                //Hell full of OP bosses
                #region God Arc
                case "God Arc":
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "98";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "02"; //Keres

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "3F900000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "28";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "28";
                    survivalCode.weaponNumber = "05"; //Charade #SET add a lot of piercing damage

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FC0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = "00"; //Assassin #SET poisons you and steal your hp

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FC0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "81";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "07"; //Berserker

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "26";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "26";
                    survivalCode.weaponNumber = "00"; //Abyss

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = "40000000"; //Decrease/Increase Attack
                    survivalCode.defense = "3F000000"; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "4D";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "06"; //Strife #set stop hp drain

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = "05"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "3FB00000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "30";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "30";
                    survivalCode.weaponNumber = "04"; //Amy

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "1E";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "0E";
                    survivalCode.weaponNumber = "06"; //Lizard Men #set drain hp, each attack should recover about 50% hp

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "07";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "11";
                    survivalCode.weaponNumber = "00"; //Siegfried with Nightmare fighting style

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = "05"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = "3FA00000"; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "31";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "31";
                    survivalCode.weaponNumber = ""; //Collosus

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "4100"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "15";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "15";
                    survivalCode.weaponNumber = "05"; //Raphael using Nightmare weapon

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FC0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = "00000000"; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "12";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "12";
                    survivalCode.weaponNumber = "05"; //Astaroth

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = "05"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F00"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = "40400000"; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "02";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "02";
                    survivalCode.weaponNumber = "03"; //Seong Mi-na 

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FB0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = "3F800000"; //Damage inflicted thru guard
                    survivalCode.weaponSize = "40800000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "15";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "15";
                    survivalCode.weaponNumber = "05"; //Raphael

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Cure"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FC0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "2B";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "14";
                    survivalCode.weaponNumber = "05"; //Inferno

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FC0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = "40000000"; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = "00000000"; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "ED";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "4E";
                    survivalCode.weaponNumber = "06"; //Hyle  ADD INCREASE HEALTH WHEN GUARDING

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = "3E800000"; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "43";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "05"; //Arthur with Soul Calibur from Xianghua

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "06";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "06";
                    survivalCode.weaponNumber = "05"; //Sophitia ADD HEALTH RECOVER FOR EVERYTHING AND DEFENSE 

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "03";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "03";
                    survivalCode.weaponNumber = "05"; //Taki with Cervantes Soul Edge ADD HP DRAIN FROM PLAYER

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FC0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "3FC00000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = "00000000"; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "27";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "27";
                    survivalCode.weaponNumber = "00"; //Night Terror

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = "05"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    break;
                #endregion

                //Special with my created characters and cots with different voices
                #region Special Arc
                case "Special Arc":
                    survivalCode.stageLevel = "0010";
                    survivalCode.stageMusic = "10";
                    survivalCode.stageNumber = 1;
                    survivalCode.model = "0F";
                    survivalCode.costume = "09";
                    survivalCode.fightingStyle = "0F";
                    survivalCode.weaponNumber = "05"; //Yoshimitsu

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = "30";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "30";
                    survivalCode.weaponNumber = "04"; //Amy

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = "EA";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "06"; //Lupi

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = "2E";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "2E";
                    survivalCode.weaponNumber = "04"; //Shadow Master

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = "31";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "31";
                    survivalCode.weaponNumber = "00"; //Colossus

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = "00"; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = "3E800000"; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0000";
                    survivalCode.stageMusic = "00";
                    survivalCode.stageNumber = 6;
                    survivalCode.model = "";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "42";
                    survivalCode.weaponNumber = "04"; //Tina (Created)

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = "";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4C";
                    survivalCode.weaponNumber = "04"; //Luca (Created)

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = "";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "4A";
                    survivalCode.weaponNumber = "04"; //Yuilin (Created)

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = "A6";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "44";
                    survivalCode.weaponNumber = "02"; //Xiaoxin (Voice)

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = "A0";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "41";
                    survivalCode.weaponNumber = "02"; //Jinkai (Voice)

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "000F";
                    survivalCode.stageMusic = "0F";
                    survivalCode.stageNumber = 11;
                    survivalCode.model = "";
                    survivalCode.costume = "";
                    survivalCode.fightingStyle = "";
                    survivalCode.weaponNumber = "04"; //Berserker

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = "25";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "25";
                    survivalCode.weaponNumber = "05"; //Olcadan

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = "54";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "54";
                    survivalCode.weaponNumber = "04"; //Riese (Voice)

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = "B7";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "4D";
                    survivalCode.weaponNumber = "04"; //Eurydice (Voice)

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = "17";
                    survivalCode.costume = "09";
                    survivalCode.fightingStyle = "17";
                    survivalCode.weaponNumber = "05"; //Cassandra

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Paralysis"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F90"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "0022";
                    survivalCode.stageMusic = "18";
                    survivalCode.stageNumber = 16;
                    survivalCode.model = "AE";
                    survivalCode.costume = "02";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "01"; //Aeneas (Voice)

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Cure"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "40000000";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = "A4";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "03"; //Meiga (Voice)

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Thunder"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3FA0"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = "AE";
                    survivalCode.costume = "01";
                    survivalCode.fightingStyle = "48";
                    survivalCode.weaponNumber = "03"; //Rudiger (Voice)

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = "Fire"; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "3F60"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = "EF";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "43";
                    survivalCode.weaponNumber = "06"; //Ende

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = ""; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = "3FC00000"; //Decrease/Increase Attack
                    survivalCode.defense = "3F400000"; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    //////////////////////////////////////////////////////////////////////////////////////////////////
                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 20;
                    survivalCode.model = "";
                    survivalCode.costume = "00";
                    survivalCode.fightingStyle = "03";
                    survivalCode.weaponNumber = "05"; //Nina (Created)

                    survivalCode.aiLevel = "05"; // 00-05
                    survivalCode.weaponSpecial = ""; //Fire, Thunder, Paralysis, Cure etc
                    survivalCode.guardianForce = ""; //Keres have 05, Will o the wisp have 04
                    survivalCode.stickyFeet = ""; //Slippery Feets
                    survivalCode.speed = "4000"; //3F80 default speed

                    survivalCode.weaponEffect = ""; //0 = Nothing, 1 = Increase attack over time, 2 = Guard Impact becomes easier to perform
                    survivalCode.attack = ""; //Decrease/Increase Attack
                    survivalCode.defense = ""; //Decrease/Increase Defense
                    survivalCode.stealHp = ""; //Steal health from enemy
                    survivalCode.pierceDamage = ""; //Damage inflicted thru guard
                    survivalCode.weaponSize = "";
                    survivalCode.atkPushForce = ""; //Decrease/Increase Attack Pushback Force
                    survivalCode.counterRate = ""; //Increase Counter Chance
                    survivalCode.nullCounter = ""; //Nullify Enemies Counters chance
                    survivalCode.guardHpModify = ""; //Decrease/Increase Health while guarding enemies attacks
                    survivalCode.autoGuardImpact = ""; //Automatically Guard Impact some attacks
                    survivalCode.parryDamage = ""; //Increase Damage Received by Opponent when successfully Guard Impact
                    survivalCode.parryRegen = ""; //Recover Health when successfully Guard Impact
                    survivalCode.guardBreakRate = ""; //Increase Guard Break Chance
                    survivalCode.throwEscapeChance = ""; //Increase Throw Escape Rate
                    survivalCode.ringOutEscapeChance = ""; //Increase Ring-Out Escape Rate
                    survivalCode.hpRegenOrDrain = ""; //Drain/Recover Health over Time
                    survivalCode.hpRegenOrDrainOnAtk = ""; //Drain/Recover Health when Attacking
                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    break;
                #endregion

                //Random characters and modifiers
                #region Mysterious Arc
                case "Mysterious Arc":

                    Random rnd = new Random();

                    string selectedDifficulty = "";
                    switch (SettingsClass.OpponentControl)
                    {
                        case 2:
                            selectedDifficulty = "00"; //Easy
                            break;
                        case 3:
                            selectedDifficulty = "01"; //Normal
                            break;
                        case 4:
                            selectedDifficulty = "02"; //Hard
                            break;
                        case 5:
                            selectedDifficulty = "03"; //Very Hard
                            break;
                        case 6:
                            selectedDifficulty = "04"; //Ultra Hard
                            break;
                        case 7:
                            selectedDifficulty = "05"; //Extremely Hard
                            break;
                        default:
                            selectedDifficulty = "01"; //Normal
                            break;
                    }

                    
                    int selectStage1 = rnd.Next(1, 32);
                    string selectedStage1 = SurvivalModeSubCodes.GetRandomStageData(selectStage1);
                    int selectStage2 = rnd.Next(1, 32);
                    string selectedStage2 = SurvivalModeSubCodes.GetRandomStageData(selectStage2);
                    int selectStage3 = rnd.Next(1, 32);
                    string selectedStage3 = SurvivalModeSubCodes.GetRandomStageData(selectStage3);
                    int selectStage4 = rnd.Next(1, 32);
                    string selectedStage4 = SurvivalModeSubCodes.GetRandomStageData(selectStage4);

                    int CharacterLocation = 0;
                    string CharacterCode = "";
                    int weaponNumber = 0;
                    string weaponCode = "";
                    int modifierPick = 0;

                    //Enemy 1
                    CharacterLocation = rnd.Next(1, 11); //10 is max
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "1-3");

                    survivalCode.stageLevel = selectedStage1;
                    survivalCode.stageMusic = selectedStage1.Substring(2, 2);
                    survivalCode.stageNumber = 1;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    //Enemy 2
                    CharacterLocation = rnd.Next(1, 11);
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "1-3");

                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 2;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    //Enemy 3
                    CharacterLocation = rnd.Next(1, 11);
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "1-3");

                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 3;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    //Enemy 4
                    CharacterLocation = rnd.Next(1, 11);
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "4-9");

                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 4;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    //Enemy 5
                    CharacterLocation = rnd.Next(1, 11);
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "4-9");

                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 5;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    //Enemy 6
                    CharacterLocation = rnd.Next(1, 11); //10 is max
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "4-9");

                    survivalCode.stageLevel = selectedStage2;
                    survivalCode.stageMusic = selectedStage2.Substring(2, 2);
                    survivalCode.stageNumber = 6;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    //Enemy 7
                    CharacterLocation = rnd.Next(1, 11); //10 is max
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "4-9");

                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 7;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    //Enemy 8
                    CharacterLocation = rnd.Next(1, 11); //10 is max
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "4-9");

                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 8;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    //Enemy 9
                    CharacterLocation = rnd.Next(1, 11); //10 is max
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "4-9");

                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 9;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    //Enemy 10
                    CharacterLocation = rnd.Next(1, 11); //10 is max
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "10-15");

                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 10;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    //Enemy 11
                    CharacterLocation = rnd.Next(1, 11); //10 is max
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "10-15");

                    survivalCode.stageLevel = selectedStage3;
                    survivalCode.stageMusic = selectedStage3.Substring(2, 2);
                    survivalCode.stageNumber = 11;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    //Enemy 12
                    CharacterLocation = rnd.Next(1, 11); //10 is max
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "10-15");

                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 12;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    //Enemy 13
                    CharacterLocation = rnd.Next(1, 11); //10 is max
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "10-15");

                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 13;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    //Enemy 14
                    CharacterLocation = rnd.Next(1, 11); //10 is max
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "10-15");

                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 14;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    //Enemy 15
                    CharacterLocation = rnd.Next(1, 11); //10 is max
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "10-15");

                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 15;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    //Enemy 16
                    CharacterLocation = rnd.Next(1, 11); //10 is max
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "16-19");

                    survivalCode.stageLevel = selectedStage4;
                    survivalCode.stageMusic = selectedStage4.Substring(2, 2);
                    survivalCode.stageNumber = 16;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    //Enemy 17
                    CharacterLocation = rnd.Next(1, 11); //10 is max
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "16-19");

                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 17;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    //Enemy 18
                    CharacterLocation = rnd.Next(1, 11); //10 is max
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "16-19");

                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 18;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    //Enemy 19
                    CharacterLocation = rnd.Next(1, 11); //10 is max
                    CharacterCode = SurvivalModeSubCodes.GetRandomCharacterData(CharacterLocation);
                    weaponCode = SurvivalModeSubCodes.GetRandomWeaponData(CharacterCode.Substring(4, 2));
                    modifierPick = rnd.Next(1, 6);
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "16-19");

                    survivalCode.stageLevel = "";
                    survivalCode.stageMusic = "";
                    survivalCode.stageNumber = 19;
                    survivalCode.model = CharacterCode.Substring(0, 2);
                    survivalCode.costume = CharacterCode.Substring(2, 2);
                    survivalCode.fightingStyle = CharacterCode.Substring(4, 2);
                    survivalCode.weaponNumber = weaponCode;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);

                    //Enemy 20 (Boss)
                    modifierPick = rnd.Next(1, 5); //boss pick
                    survivalCode = SurvivalModeSubCodes.GetRandomModifiers(modifierPick, "20");

                    survivalCode.stageNumber = 20;
                    survivalCode.aiLevel = selectedDifficulty;

                    stageCode += SurvivalModeSubCodes.GetStageCode(survivalCode);
                    break;
                    #endregion

            }

            string timeCode = Environment.NewLine + "patch=1,EE,204ED89C,extended,000003E8 //Time Limit set to 1000 seconds" + Environment.NewLine;
            stageCode = timeCode + stageCode;

            string survivalCodeNotLite = stageCode;

            SettingsClass.LoadData();
            stageCode += Codes.NewWeapons.GetWeaponsCode(SettingsClass.UltimateWeapons, false, false);
            stageCode += Codes.CharacterSelect.GetCharacterPnachCode(true, true);

            File.WriteAllText(SettingsClass.codeFilePath, stageCode, Encoding.UTF8);

            if (liteMode == true)
            {
                return "ok";
            }
            else
            {
                return survivalCodeNotLite;
            }
        }

    }
}
