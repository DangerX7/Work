﻿using System;
using System.IO;

class Program
{
    static void Main()
    {
        Console.WriteLine("Do you want to add or remove?");

        while (true)
        {
            Console.WriteLine("a = add main; a1 = add all; r = remove");
            var decision = Console.ReadLine();

            string sourcePath = @"E:\CopyFrom\";
            string destinationPath = @"E:\PasteTo\";

            string file1_sourcePath = sourcePath + "document.txt";
            string file1_destinationPath = destinationPath + "document.txt";

            string folder1_sourcePath = sourcePath + "CopyFolderTest";
            string folder1_destinationPath = destinationPath + "CopyFolderTest";

            if (decision == "a")
            {
                try
                {
                    CopyFile(file1_sourcePath, file1_destinationPath);
                    CopyFolder(folder1_sourcePath, folder1_destinationPath);
                    Console.WriteLine("Added main files.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
                break;
            }
            else if (decision == "a1")
            {
                try
                {
                    CopyFile(file1_sourcePath, file1_destinationPath);
                    CopyFolder(folder1_sourcePath, folder1_destinationPath);
                    Console.WriteLine("Added all files.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
                break;
            }
            else if (decision == "r")
            {
                try
                {
                    DeleteFile(file1_destinationPath);
                    DeleteFolder(folder1_destinationPath);
                    Console.WriteLine("Removed all files.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
                break;
            }
            else
            {
                Console.WriteLine("Invalid input, try again!");
            }
        }



    }

    static void CopyFile(string sourcePath, string destinationPath)
    {
        if (!File.Exists(sourcePath))
        {
            throw new FileNotFoundException("Source file not found.", sourcePath);
        }

        string destDirectory = Path.GetDirectoryName(destinationPath);
        if (!Directory.Exists(destDirectory))
        {
            Directory.CreateDirectory(destDirectory);
        }

        File.Copy(sourcePath, destinationPath, true);
    }

    static void DeleteFile(string filePath)
    {
        if (!File.Exists(filePath))
        {
            throw new FileNotFoundException("File not found.", filePath);
        }

        File.Delete(filePath);
    }

    static void CopyFolder(string sourceFolder, string destinationFolder)
    {
        if (!Directory.Exists(sourceFolder))
        {
            throw new DirectoryNotFoundException($"Source folder not found: {sourceFolder}");
        }

        // Create destination folder if it doesn't exist
        Directory.CreateDirectory(destinationFolder);

        // Copy all files
        foreach (string file in Directory.GetFiles(sourceFolder))
        {
            string destFile = Path.Combine(destinationFolder, Path.GetFileName(file));
            File.Copy(file, destFile, true);
        }

        // Copy all subdirectories
        foreach (string subDir in Directory.GetDirectories(sourceFolder))
        {
            string destSubDir = Path.Combine(destinationFolder, Path.GetFileName(subDir));
            CopyFolder(subDir, destSubDir); // Recursive call for subdirectories
        }
    }

    static void DeleteFolder(string folderPath)
    {
        if (!Directory.Exists(folderPath))
        {
            throw new DirectoryNotFoundException($"Folder not found: {folderPath}");
        }

        Directory.Delete(folderPath, true);
    }
}
