﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SC3_pnach_editor.Services
{
    public class InfoClass
    {
        public static string editorVersion = "Version 1.4";
        public static string editorReleaseDate = "Release Date 6/2/2024";
        public static string discordServer = "https://discord.gg/dSWf2et8g7";
    }
}
