﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using NAudio.CoreAudioApi;
using NAudio.Gui;
using NAudio.Wave;
using OfficeOpenXml;
using SC3_pnach_editor.Codes;
using SC3_pnach_editor.Services;
using SC3_pnach_editor.ViewModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace SC3_pnach_editor.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class SpecialEffectsView : UserControl
    {
        SpecialEffectsViewModel viewModel;
        public SpecialEffectsView()
        {

            InitializeComponent();

            viewModel = new();

            this.DataContext = viewModel;


            SettingsClass.LoadData();

        }

        private void GoToMainPage_Click(object sender, RoutedEventArgs e)
        {
            SettingsClass.SaveData();
            viewModel.DisplayMainView();
        }
        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            //if (sender is CheckBox chk)
            //{
            //    string name = chk.Name;
            //    bool isChecked = chk.IsChecked == true;

            //    // now you can branch logic based on Name
            //    switch (name)
            //    {
            //        case "AllGuardBreakP1":

            //            break;

            //        case "AllGuardBreakP2":

            //            break;

            //        case "AllUnblockableP1":

            //            break;

            //        case "AllUnblockableP2":

            //            break;

            //        case "ParalysisP1":

            //            break;

            //        case "ParalysisP2":

            //            break;

            //        case "DownLoseP1":

            //            break;

            //        case "DownLoseP2":

            //            break;
            //    }
            //}
        }
        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            //if (sender is CheckBox chk)
            //{
            //    string name = chk.Name;
            //    switch (name)
            //    {
            //        case "AllGuardBreakP1":

            //            break;

            //        case "AllGuardBreakP2":

            //            break;

            //        case "AllUnblockableP1":

            //            break;

            //        case "AllUnblockableP2":

            //            break;
            //    }
            //}
        }

        private void SkinPreview(object sender, MouseEventArgs e)
        {

        }
    }




}
